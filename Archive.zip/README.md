# Amazon Affiliates Chrome Extension

Install it from the Chrome Store: <br/>
https://chrome.google.com/webstore/detail/amazon-affiliates/laebfeeomkndpdnhohpojpobgmekfhmj